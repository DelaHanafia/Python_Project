class MenuItem:
    pass


menu_item1 = MenuItem()

menu_item1.name = 'Roti Lapis'
print(menu_item1.name)

# Tentukan price menu_item1 ke 5
menu_item1.price = 5

# Cetak price dari menu_item1
print(menu_item1.price)
