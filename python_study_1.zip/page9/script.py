age = 24
# Cetak 'Saya berusia 24 tahun' menggunakan variable age
print('Saya berusia'  + str(age) + 'tahun')

count = '5'
# Ubah variable count ke tipe data integer, tambahkan 1, dan cetak hasilnya
print(int(count) + 1)
