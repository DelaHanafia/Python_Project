money = 2
apple_price = 4

if money >= apple_price:
    print('Anda dapat membeli apel')
# Ketika kondisi di atas adalah False, cetak 'Uang Anda tidak mencukupi'
else:
  print('Uang Anda tidak mencukupi')

