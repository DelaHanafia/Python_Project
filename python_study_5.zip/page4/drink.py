from menu_item import MenuItem

class Drink(MenuItem):
    pass
