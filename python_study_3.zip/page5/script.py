# Tambahkan nilai default untuk name
def print_hand(hand, name='Tamu'):
    print(name + ' memilih: ' + hand)

# Tambahkan argument ke print_hand
print_hand('Batu')