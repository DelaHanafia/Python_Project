# Cetak hasil dari 9 / 2
print(9/2)

# Cetak hasil dar 7 * 5
print(7*5)

# Cetak sisa dari 5 dibagi 2 menggunakan %
print(5%2)